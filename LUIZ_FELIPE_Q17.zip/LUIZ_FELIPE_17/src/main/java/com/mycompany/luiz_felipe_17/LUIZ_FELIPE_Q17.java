/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.luiz_felipe_17;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author lbizio
 */
public class LUIZ_FELIPE_Q17 {

    public static void main(String[] args) throws IOException {
        String nome; 
        float peso; 
        
        nome= JOptionPane.showInputDialog(null,"Qual o seu nome?: "); 
        String a = JOptionPane.showInputDialog(null,"qual o seu peso?: "); 
        peso = Float.parseFloat(a); 
        FileWriter arquivo = new FileWriter("D:\\Users\\lbizio\\Desktop\\arquivo.txt");  
        PrintWriter arquivoTxt = new PrintWriter(arquivo); 
        if(peso < 65){ 
        arquivoTxt.println("O lutador "+ nome +" pesa "+ peso +" e se enquadra na categoria pena"); 
    }
        else if(peso < 72){ 
        arquivoTxt.println("O lutador "+ nome +" pesa "+ peso +" e se enquadra na categoria leve"); 
        }
        else if(peso < 79){ 
        arquivoTxt.println("O lutador "+ nome +" pesa "+ peso +" e se enquadra na categoria ligeiro"); 
        }
        else if(peso <86){ 
        arquivoTxt.println("O lutador "+ nome +" pesa "+ peso +" e se enquadra na categoria meio médio"); 
        }
        else if(peso <93){ 
        arquivoTxt.println("O lutador "+ nome +" pesa "+ peso +" e se enquadra na categoria médio"); 
        }
        else if(peso <93){
        arquivoTxt.println("O lutador "+ nome +" pesa "+ peso +" e se enquadra na categoria meio pesado"); 
        }
        else{ arquivoTxt.println("O lutador "+ nome +" pesa "+ peso +" e se enquadra na categoria pesado"); 
        }
        arquivo.close(); 
    }
}
