/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.luiz_felipe_q4;

import java.util.Scanner;

/**
 *
 * @author lbizio
 */
public class LUIZ_FELIPE_Q4 {

    public static void main(String[] args) {
            Scanner ler = new Scanner(System.in);
        
        System.out.println("Digite o código de usuário: ");
        int codUs = ler.nextInt();
        
        if (codUs!= 1234){
            System.out.println("Usuário inválido!");
        }else if(codUs == 1234){
            System.out.println("Digite sua senha: ");
            int senha = ler.nextInt();
            
            if (senha != 9999){
                System.out.println("Senha Incorreta");
            }else {
                System.out.println("Acesso Permitido");
            }
        }
    }
}
