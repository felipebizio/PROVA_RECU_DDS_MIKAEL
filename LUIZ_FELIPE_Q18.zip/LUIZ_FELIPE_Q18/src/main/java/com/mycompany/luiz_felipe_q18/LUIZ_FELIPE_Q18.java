/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.luiz_felipe_q18;

import java.util.Scanner;

/**
 *
 * @author lbizio
 */
public class LUIZ_FELIPE_Q18 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        
        System.out.println("Quanto você ganha por hora? ");
        float sal = ler.nextInt();
        System.out.println("Quantas horas você trabalha por mês? ");
        float hora = ler.nextInt();
        
        float salBr = sal * hora;
        float pagIr = (float) (salBr * 0.11);
        float pagInss = (float) (salBr * 0.08);
        float pagSin = (float) (salBr * 0.05);
        float salLiq = salBr - pagIr - pagInss - pagSin;
        
        System.out.println("Salário Bruto: "+salBr);
        System.out.println("Imposto de Renda: "+ pagIr);
        System.out.println("INSS: "+ pagInss);
        System.out.println("Sindicato: "+ pagSin);
        System.out.println("Salário Líquido: "+ salLiq);
        
    }
}
