/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.luiz_felipe_q2;

import java.util.Scanner;

/**
 *
 * @author lbizio
 */
public class LUIZ_FELIPE_Q2 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int cafe = 0, cafeC = 0,leiteC = 0;
        //int qtdCafe, qtdCafeC, qtdLeiteC;
        
        for(int i=0; i<=100;i++){
            System.out.println("Escolha a opção desejada!\n1 - Café Expresso\n2 - Café Capuccino\n"
+ "3 - Leite com café\n4 - Totalizar vendas ");        
        int esc = scanner.nextInt();
            if (esc == 1){
                cafe=cafe+1;
            }else if (esc == 2){
                cafeC=cafeC + 1;
            }else if (esc == 3){
                leiteC=leiteC+1;
            }else if (esc == 4){
                System.out.println("Foram vendidos "+ cafe+ " café expresso e totalizou " + cafe*0.75+ " reais.");
                System.out.println("Foram vendidos "+ cafeC+ " café capuccino e totalizou " + cafeC*1 + " reais.");
                System.out.println("Foram vendidos "+ leiteC+ " leite com café e totalizou " + leiteC*1.25 + " reais.");
                System.out.println("Foram vendidos "+ (cafe+cafeC+leiteC)+  " café expresso e totalizou " + (cafe*0.75+cafeC*1+leiteC*1.25)+ " reais.");   
                break;
            }
        }
    }   
   
}